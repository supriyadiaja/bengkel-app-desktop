# Bengkel Maju Jaya — Setup Guide

## Struktur File yang Perlu Ditambahkan

```
src/
├── index.css                    ← Global styles + CSS variables
├── App.js                       ← Root component, routing, auth gate
├── context/
│   └── AppContext.jsx           ← Global state (toast, currentUser)
├── utils/
│   └── format.js                ← Helpers: formatRupiah, formatDate, dll
├── components/
│   ├── UI.jsx                   ← Shared components (Button, Card, Modal, Table, dll)
│   └── Layout.jsx               ← Sidebar + topbar layout
└── pages/
    ├── LoginPage.jsx            ← PIN login screen
    ├── Dashboard.jsx            ← Overview + chart + recent invoices
    ├── InvoicePage.jsx          ← CRUD invoice + print
    ├── PelangganPage.jsx        ← CRUD pelanggan + riwayat
    ├── SparepartPage.jsx        ← Inventory + stok masuk
    ├── LaporanPage.jsx          ← Laporan harian/bulanan
    └── SettingsPages.jsx        ← Printer, profil bengkel, akun
```

## Langkah Install

### 1. Copy semua file ke project kamu
Salin file-file di atas ke folder `src/` yang sudah ada.

### 2. Install dependencies yang belum ada
```bash
npm install lucide-react
```
Paket lain sudah ada di package.json kamu.

### 3. Ganti src/App.js yang lama
Hapus isi App.js bawaan Create React App, ganti dengan file baru.

### 4. Ganti src/index.css
Hapus isi index.css bawaan, ganti dengan file baru.

### 5. Jalankan
```bash
npm run dev
```
Atau untuk production build:
```bash
npm run build
```

## Catatan Penting

### Electron IPC
- Semua page menggunakan `window.api.invoke()` yang sudah didefinisikan di `preload.js` kamu
- Jika `window.api` tidak ada (browser dev mode), akan menggunakan mock data otomatis
- Jadi bisa develop UI di browser dulu sebelum test di Electron

### Auth & Role
- **Admin (PIN: 1234)** → akses semua termasuk laporan keuangan & akun
- **Kasir (PIN: 0000)** → invoice, pelanggan, sparepart saja
- Ganti PIN default segera setelah pertama install!

### Thermal Printer
- Pastikan driver printer sudah terinstall di Windows
- Cek nama printer di Control Panel → Devices & Printers
- Masukkan nama tersebut di Pengaturan → Konfigurasi Printer
- Klik "Test Print" untuk verifikasi koneksi

### Database
- SQLite otomatis terbuat di `%AppData%\Roaming\Electron\bengkel.db`
- Backup rutin disarankan: copy file .db ke tempat aman

## Build ke .exe

```bash
npm run build
```
Output installer ada di folder `dist/`.
